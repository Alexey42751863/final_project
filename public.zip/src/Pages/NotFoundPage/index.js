import NotFoundPage from "./NotFoundPage";
export default NotFoundPage