import React from 'react'

const TermsOfUse = () => {
  return (
    <div>TermsOfUse</div>
  )
}

export default TermsOfUse