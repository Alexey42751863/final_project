import TermsOfUse from "./TermsOfUse";
export default TermsOfUse