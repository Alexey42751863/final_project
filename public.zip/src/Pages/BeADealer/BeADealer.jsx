import React from 'react'

const BeADealer = () => {
  return (
    <div>BeADealer</div>
  )
}

export default BeADealer