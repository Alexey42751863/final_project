import BeADealer from "./BeADealer"
export default BeADealer