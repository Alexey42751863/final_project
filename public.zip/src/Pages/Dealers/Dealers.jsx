import React from 'react'

const Dealers = () => {
  return (
    <div>Dealers</div>
  )
}

export default Dealers