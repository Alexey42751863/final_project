import React from 'react'

const Advertising = () => {
  return (
    <div>Advertising</div>
  )
}

export default Advertising